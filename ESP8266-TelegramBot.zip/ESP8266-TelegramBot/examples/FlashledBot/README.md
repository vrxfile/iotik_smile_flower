#ESP8266 - Flashled Bot

Flashled Bot executes orders received from Telegram and returns its status.

This Example shows how to use a Bot from Telegram. You will learn how to use a command written to your Bot from telegram and execute it with an ESP8266 board.

Application written by [Giancarlo Bacchio](giancarlo.bacchio@gmail.com)



## License

You may copy, distribute and modify the software provided that modifications are described and licensed for free under [LGPL-3](http://www.gnu.org/licenses/lgpl-3.0.html). Derivatives works (including modifications or anything statically linked to the library) can only be redistributed under [LGPL-3](http://www.gnu.org/licenses/lgpl-3.0.html), but applications that use the library don't have to be.




