#ESP8266 - Echo Bot

Echo Bot receives messages and reply like a parrot.

This Example shows how to use a Bot from Telegram. You will learn how to write a message to your Bot from telegram and receive a reply with an ESP8266 board.

Application written by [Giancarlo Bacchio](giancarlo.bacchio@gmail.com)



## License

You may copy, distribute and modify the software provided that modifications are described and licensed for free under [LGPL-3](http://www.gnu.org/licenses/lgpl-3.0.html). Derivatives works (including modifications or anything statically linked to the library) can only be redistributed under [LGPL-3](http://www.gnu.org/licenses/lgpl-3.0.html), but applications that use the library don't have to be.




